build_report_linux_patch
========

Installs Apache and creates a report based on facts from Linux patching

Requirements
------------

Must run on Apache server

Role Variables / Configuration
--------------

N/A

Dependencies
------------

N/A

Example Playbook
----------------

The role can be used to create an html report on any number of Linux hosts using any number of Linux servers about their patching results(yum and dnf)


```
---
- hosts: all

  tasks:
  - name: Run Windows Report
    import_role:
      name: shadowman.reports.build_report_linux_patch
      
```